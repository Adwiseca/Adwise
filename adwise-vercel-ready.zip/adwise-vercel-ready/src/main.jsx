import React from 'react';
import ReactDOM from 'react-dom/client';
import AdWiseCanada from './AdWiseCanada.jsx';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <AdWiseCanada />
  </React.StrictMode>
);
