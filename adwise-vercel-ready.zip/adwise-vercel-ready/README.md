# AdWise Canada — Vercel Ready

## Run locally
```bash
npm install
npm run dev
```

## Deploy to Vercel
1. Upload this project to GitHub.
2. Import the GitHub repo in Vercel.
3. Add Environment Variable:
   - Name: `ANTHROPIC_API_KEY`
   - Value: your Anthropic API key
4. Deploy.

The React app is in `src/`.
The server API function is in `api/chat.js`.
